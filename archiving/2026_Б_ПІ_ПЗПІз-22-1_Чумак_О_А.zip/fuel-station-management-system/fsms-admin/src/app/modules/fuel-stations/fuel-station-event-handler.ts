import { inject, Injectable } from "@angular/core";
import {
  FuelOrderConfirmed,
  FuelOrderCreated,
  FuelOrderEvent,
  FuelOrderProcessed,
  FuelOrderRejected,
  FuelPriceChanged,
  FuelPurchaseCreated,
  FuelSaleCreated,
  FuelStationDeactivated,
  FuelStationEvent,
  FuelStationRestClient,
  FuelStationStompClient,
  FuelTank,
  FuelTankDecommissioned,
  FuelTankInstalled,
  ManagerAssignedToFuelStation,
  ManagerRestClient,
  ManagerUnassignedFromFuelStation,
} from "fsms-web-api";
import { Observable, tap } from "rxjs";
import { LoggerService } from "../common/logger";
import { FuelOrderEventHandler } from "../fuel-orders/fuel-order-event-handler";
import { FuelStationStore } from "./stores/fuel-station-store";
import { Router } from "@angular/router";
import { FuelStationEventsStore } from "./stores/fuel-station-events-store";

@Injectable({ providedIn: "root" })
export class FuelStationEventHandler {

  private readonly router = inject(Router);
  private readonly logger = inject(LoggerService);

  private readonly fuelStationStore = inject(FuelStationStore);
  private readonly fuelStationEventsStore = inject(FuelStationEventsStore);

  private readonly managerRestClient = inject(ManagerRestClient);
  private readonly fuelStationStompClient = inject(FuelStationStompClient);
  private readonly fuelStationRestClient = inject(FuelStationRestClient);

  private readonly fuelOrderEventHandler = inject(FuelOrderEventHandler);

  start(fuelStationId: number): Observable<FuelStationEvent | FuelOrderEvent> {
    this.logger.log('[FuelStationEventHandler] Starting event subscription for fuelStationId:', fuelStationId);
    return this.fuelStationStompClient.onFuelStationAll(fuelStationId).pipe(
      tap((event) => {
        this.logger.log('[FuelStationEventHandler] Event received:',event.constructor.name, event);
        this.fuelStationEventsStore.prependEventByOccurredAt(event.occurredAt);

        if (event instanceof FuelPriceChanged) {
          this.handleFuelPriceChanged(event);
        } else if (event instanceof FuelStationDeactivated) {
          this.handleFuelStationDeactivated();
        } else if (event instanceof ManagerAssignedToFuelStation) {
          this.handleManagerAssigned(event);
        } else if (event instanceof ManagerUnassignedFromFuelStation) {
          this.handleManagerUnassigned(event);
        } else if (event instanceof FuelTankDecommissioned) {
          this.handleFuelTankDecommissioned(event);
        } else if (event instanceof FuelTankInstalled) {
          this.handleFuelTankInstalled(event);
        } else if (event instanceof FuelOrderCreated) {
          this.handleFuelOrderCreated(event);
        } else if (event instanceof FuelOrderConfirmed) {
          this.handleFuelOrderConfirmed(event);
        } else if (event instanceof FuelOrderRejected) {
          this.handleFuelOrderRejected(event);
        } else if (event instanceof FuelOrderProcessed) {
          this.handleFuelOrderProcessed(event);
        } else if (event instanceof FuelPurchaseCreated) {
          this.handleFuelPurchaseCreated(event);
        } else if (event instanceof FuelSaleCreated) {
          this.handleFuelSaleCreated(event);
        }
      })
    );
  }

  private handleFuelPriceChanged(event: FuelPriceChanged): void {
    const newFuelStation = this.fuelStationStore.fuelStation.clone();
    newFuelStation.updateFuelPrice(event.fuelGrade, event.pricePerLiter);
    this.fuelStationStore.fuelStation = newFuelStation;
  }

  private handleFuelStationDeactivated(): void {
    this.router.navigate(["/"])
  }

  private handleManagerAssigned(event: ManagerAssignedToFuelStation): void {
    if(this.fuelStationStore.fuelStation.isManagerAssigned(event.managerId)) {
      return;
    }

    const newFuelStation = this.fuelStationStore.fuelStation.clone();
    newFuelStation.assignManger(event.managerId);
    this.fuelStationStore.fuelStation = newFuelStation;

    if(this.fuelStationStore.managers === null) {
      return;
    }

    this.managerRestClient.getManagerById(event.managerId)
      .pipe(tap((manager) => {
        if(this.fuelStationStore.managers === null) {
          return;
        }
        this.fuelStationStore.managers = [...this.fuelStationStore.managers, manager];
      }))
      .subscribe();
  }

  private handleFuelTankDecommissioned(event: FuelTankDecommissioned): void {
    const newFuelStation = this.fuelStationStore.fuelStation.clone();
    newFuelStation.removeFuelTank(event.fuelTankId);
    this.fuelStationStore.fuelStation = newFuelStation;
  }

  private handleFuelTankInstalled(event: FuelTankInstalled): void {
    const newFuelStation = this.fuelStationStore.fuelStation.clone();
    newFuelStation.addFuelTank(new FuelTank(
      event.fuelTankId,
      0,
      0,
      event.maxCapacity,
      event.fuelGrade,
      null
    ));
    this.fuelStationStore.fuelStation = newFuelStation;
  }

  private handleManagerUnassigned(event: ManagerUnassignedFromFuelStation): void {
    const newFuelStation = this.fuelStationStore.fuelStation.clone();
    newFuelStation.unassignManger(event.managerId);

    this.fuelStationStore.fuelStation = newFuelStation;

    if(this.fuelStationStore.managers !== null) {
      this.fuelStationStore.managers = this.fuelStationStore.managers.filter(
        (manager) => manager.managerId !== event.managerId
      );
    }
  }

  private handleFuelOrderCreated(event: FuelOrderCreated): void {
    if(this.fuelStationStore.fuelOrders === null) {
      return;
    }

    this.fuelOrderEventHandler.handleFuelOrderCreated(event.fuelOrderId, this.fuelStationStore.fuelOrders)
      .pipe(tap((fuelOrders) => this.fuelStationStore.fuelOrders = fuelOrders))
      .subscribe()
  }

  private handleFuelOrderConfirmed(event: FuelOrderConfirmed): void {
    if(this.fuelStationStore.fuelOrders === null) {
      return;
    }

    this.fuelStationStore.fuelOrders = this.fuelOrderEventHandler
      .handleFuelOrderConfirmed(event.fuelOrderId, this.fuelStationStore.fuelOrders)
  }

  private handleFuelOrderRejected(event: FuelOrderRejected): void {
    if(this.fuelStationStore.fuelOrders === null) {
      return;
    }

    this.fuelStationStore.fuelOrders = this.fuelOrderEventHandler
      .handleFuelOrderRejected(event.fuelOrderId, this.fuelStationStore.fuelOrders)
  }

  private handleFuelPurchaseCreated(event: FuelPurchaseCreated): void {
    if (this.fuelStationStore.fuelPurchases === null) {
      return;
    }
    this.fuelStationRestClient.getFuelStationFuelPurchases(event.fuelStationId)
      .pipe(tap(purchases => this.fuelStationStore.fuelPurchases = purchases))
      .subscribe();
  }

  private handleFuelSaleCreated(event: FuelSaleCreated): void {
    if (this.fuelStationStore.fuelSales === null) {
      return;
    }
    this.fuelStationRestClient.getFuelStationFuelSales(event.fuelStationId)
      .pipe(tap(sales => this.fuelStationStore.fuelSales = sales))
      .subscribe();
  }

  private handleFuelOrderProcessed(event: FuelOrderProcessed): void {
    this.fuelStationRestClient.getFuelStationById(event.fuelStationId)
      .pipe(tap((fuelStation) => this.fuelStationStore.fuelStation = fuelStation))
      .subscribe()

    if(this.fuelStationStore.fuelOrders === null) {
      return;
    }
    this.fuelStationStore.fuelOrders = this.fuelOrderEventHandler
      .handleFuelOrderProcessed(event.fuelOrderId, this.fuelStationStore.fuelOrders)
  }

}