import { Routes } from '@angular/router';
import { FuelStationPage } from './pages/fuel-stations/[id]/fuel-station.page';
import { LoginPage } from './pages/login/login.page';
import { FuelStationsPage } from './pages/fuel-stations/fuel-stations.page';
import { FuelStationInfoPage } from './pages/fuel-stations/[id]/fuel-station-info/fuel-station-info.page';
import { FuelStationManagersPage } from './pages/fuel-stations/[id]/fuel-station-managers/fuel-station-managers.page';
import { FuelStationFuelOrdersPage } from './pages/fuel-stations/[id]/fuel-station-fuel-orders/fuel-station-fuel-orders.page';
import { FuelStationFuelTanksPage } from './pages/fuel-stations/[id]/fuel-station-fuel-tanks/fuel-station-fuel-tanks.page';
import { FuelStationFuelPricesPage } from './pages/fuel-stations/[id]/fuel-station-fuel-prices/fuel-station-fuel-prices.page';
import { FuelStationEventsPage } from './pages/fuel-stations/[id]/fuel-station-events/fuel-station-events.page';
import { FuelStationFinancePage } from './pages/fuel-stations/[id]/fuel-station-finance/fuel-station-finance.page';
import { ManagersPage } from './pages/managers/managers.page';
import { FuelOrdersPage } from './pages/fuel-orders/fuel-orders.page';
import { FuelPricesPage } from './pages/fuel-prices/fuel-prices.page';
import {adminGuard, } from "fsms-security"

export const routes: Routes = [
    { path: "", component: FuelStationsPage, canActivate: [adminGuard] },
    { path: "login", component: LoginPage },
    { 
        path: "fuel-stations/:id", 
        component: FuelStationPage, 
        canActivate: [adminGuard],
        children: [
            { path: "info", component: FuelStationInfoPage },
            { path: "managers", component: FuelStationManagersPage },
            { path: "fuel-orders", component: FuelStationFuelOrdersPage },
            { path: "fuel-tanks", component: FuelStationFuelTanksPage },
            { path: "fuel-prices", component: FuelStationFuelPricesPage },
            { path: "fuel-purchases", component: FuelStationFinancePage },
            { path: "events", component: FuelStationEventsPage },
            { path: "", redirectTo: "info", pathMatch: "full" }
        ]
    },
    { path: "managers", component: ManagersPage, canActivate: [adminGuard]},
    { path: "fuel-orders", component: FuelOrdersPage, canActivate: [adminGuard]},
    { path: "fuel-prices", component: FuelPricesPage, canActivate: [adminGuard]}
];