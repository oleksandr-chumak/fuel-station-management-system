package com.fuelstation.managmentapi.fuelorder.infrastructure.persistence;

import com.fuelstation.managmentapi.common.domain.Actor;
import com.fuelstation.managmentapi.common.domain.ActorType;
import com.fuelstation.managmentapi.common.domain.CurrencyCode;
import com.fuelstation.managmentapi.fuelorder.domain.events.*;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Map;

@Repository
@AllArgsConstructor
public class FuelOrderEventRepositoryImpl implements FuelOrderEventRepository {

    private final JpaFuelOrderEventRepository jpaFuelOrderEventRepository;
    private final ObjectMapper objectMapper;

    @Override
    public FuelOrderEvent save(FuelOrderEvent event) {
        Map<String, Object> payload = objectMapper.convertValue(event, new TypeReference<>() {});
        payload.remove("type");
        payload.remove("occurredAt");
        payload.remove("performedBy");
        payload.remove("fuelOrderId");
        payload.remove("fuelStationId");
        payload.remove("domainEvents");

        var entity = new FuelOrderEventEntity();
        entity.setFuelOrderId(event.getFuelOrderId());
        entity.setFuelStationId(event.getFuelStationId());
        entity.setEventType(event.getType().name());
        entity.setOccurredAt(event.getOccurredAt().atOffset(ZoneOffset.UTC));
        entity.setPerformedBy(event.getPerformedBy().isSystem() ? null : event.getPerformedBy().id());
        entity.setPayload(payload.isEmpty() ? null : payload);

        jpaFuelOrderEventRepository.save(entity);

        return event;
    }

    @Override
    public Page<FuelOrderEvent> findByFuelStationIdAfter(Long fuelStationId, Instant occurredAfter, int limit) {
        return jpaFuelOrderEventRepository
            .findByFuelStationIdAndOccurredAt(
                fuelStationId,
                occurredAfter.atOffset(ZoneOffset.UTC),
                PageRequest.of(0, limit, Sort.by(Sort.Direction.DESC, "occurredAt"))
            )
            .map(this::toFuelOrderEvent);
    }

    private FuelOrderEvent toFuelOrderEvent(FuelOrderEventEntity entity) {
        long fuelOrderId = entity.getFuelOrderId();
        long fuelStationId = entity.getFuelStationId();
        Actor performedBy = entity.getPerformedBy() == null ? Actor.system() : new Actor(entity.getPerformedBy(), ActorType.USER, null);
        Instant occurredAt = entity.getOccurredAt().toInstant();

        return switch (FuelOrderEventType.valueOf(entity.getEventType())) {
            case FUEL_ORDER_CREATED -> new FuelOrderCreated(fuelOrderId, fuelStationId, performedBy, occurredAt);
            case FUEL_ORDER_CONFIRMED -> {
                Map<String, Object> payload = entity.getPayload() == null ? Map.of() : entity.getPayload();
                Object priceRaw = payload.get("pricePerLiter");
                Object currencyRaw = payload.get("currency");
                BigDecimal pricePerLiter = priceRaw == null ? null : new BigDecimal(priceRaw.toString());
                CurrencyCode currency = currencyRaw == null ? null : CurrencyCode.fromString(currencyRaw.toString());
                yield new FuelOrderConfirmed(fuelOrderId, fuelStationId, pricePerLiter, currency, performedBy, occurredAt);
            }
            case FUEL_ORDER_REJECTED -> new FuelOrderRejected(fuelOrderId, fuelStationId, performedBy, occurredAt);
            case FUEL_ORDER_PROCESSED -> new FuelOrderProcessed(fuelOrderId, fuelStationId, performedBy, occurredAt);
        };
    }
}
