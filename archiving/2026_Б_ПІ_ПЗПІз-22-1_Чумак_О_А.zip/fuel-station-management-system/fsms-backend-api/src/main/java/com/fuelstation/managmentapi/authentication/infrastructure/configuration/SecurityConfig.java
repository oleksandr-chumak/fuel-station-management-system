package com.fuelstation.managmentapi.authentication.infrastructure.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.fuelstation.managmentapi.authentication.domain.UserRole;
import com.fuelstation.managmentapi.authentication.infrastructure.security.JwtTokenFilter;
import com.fuelstation.managmentapi.authentication.infrastructure.security.UserDetailsServiceImp;

@Configuration
public class SecurityConfig {

    @Value("${client.origin}")
    private String clientOrigin;

    private final JwtTokenFilter jwtTokenFilter;

    private final UserDetailsServiceImp userDetailsServiceImp;

    public SecurityConfig(JwtTokenFilter jwtTokenFilter, UserDetailsServiceImp userDetailsServiceImp) {
        this.jwtTokenFilter = jwtTokenFilter;
        this.userDetailsServiceImp = userDetailsServiceImp;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) {
        http.cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(AbstractHttpConfigurer::disable)
            .authorizeHttpRequests(
                req -> req
                    .requestMatchers("/ws/**").permitAll()
                    .requestMatchers(
                        "/api/auth/admins/login",
                        "/api/auth/managers/login"
                    ).permitAll()
                    .requestMatchers(
                        "/api/fuel-stations/",
                        "/api/fuel-stations/{id}/deactivate",
                        "/api/fuel-stations/{id}/assign-manager",
                        "/api/fuel-stations/{id}/unassign-manager",
                        "/api/fuel-stations/{id}/fuel-prices",
                        "/api/fuel-stations/{id}/fuel-prices/{fuelGrade}",
                        "/api/fuel-stations/{stationId}/fuel-purchases",
                        "/api/fuel-stations/{stationId}/fuel-sales",

                        "/api/managers/",
                        "/api/managers/{id}/terminate",
                        "/api/managers/{id}",

                        "/api/fuel-orders/{id}/confirm",
                        "/api/fuel-orders/{id}/reject",
                        "/api/fuel-orders/{id}",

                        "/api/fuel-prices",
                        "/api/countries/{countryCode}/fuel-prices"
                    ).hasAuthority(UserRole.ADMINISTRATOR.name())
                    .requestMatchers(
                        "/api/fuel-stations/{id}",
                        "/api/fuel-stations/{id}/managers",
                        "/api/fuel-stations/{id}/fuel-orders",

                        "/api/fuel-orders/",

                        "/api/manager/{id}/fuel-stations"
                    ).hasAnyAuthority(UserRole.ADMINISTRATOR.name(), UserRole.MANAGER.name())
                    .anyRequest().authenticated()
            ).userDetailsService(userDetailsServiceImp)
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(jwtTokenFilter, UsernamePasswordAuthenticationFilter.class)
            .exceptionHandling(
                e -> e.accessDeniedHandler((ignored, response, ignored2) -> response.setStatus(403))
                    .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED))
            );
        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration corsConfiguration = new CorsConfiguration();
        System.out.println("Configuring CORS for origin: " + clientOrigin);
        corsConfiguration.setAllowedOrigins(List.of(clientOrigin));
        corsConfiguration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        corsConfiguration.setAllowCredentials(true);
        corsConfiguration.setAllowedHeaders(List.of("Authorization", "Content-Type", "Accept"));
        corsConfiguration.setExposedHeaders(List.of("Authorization"));
        corsConfiguration.setMaxAge(3600L);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", corsConfiguration);
        return source;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}