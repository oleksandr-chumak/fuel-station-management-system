package com.fuelstation.managmentapi.fuelstation.application.rest;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fuelstation.managmentapi.country.domain.CountryCode;
import com.fuelstation.managmentapi.common.domain.CurrencyCode;
import com.fuelstation.managmentapi.fuelstation.domain.models.FuelStation;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FuelStationResponse {
    private Long fuelStationId;
    private String street;
    private String buildingNumber;
    private String city;
    private String postalCode;
    private List<Long> assignedManagersIds;
    private List<FuelTankResponse> fuelTanks;
    private List<FuelPriceResponse> fuelPrices;
    private CountryCode country;
    private String status;

    public static FuelStationResponse fromDomain(FuelStation fuelStation) {
        return fromDomain(fuelStation, Map.of());
    }

    public static FuelStationResponse fromDomain(FuelStation fuelStation, Map<Long, BigDecimal> pendingByTankId) {
        FuelStationResponse response = new FuelStationResponse();
        response.setFuelStationId(fuelStation.getFuelStationId());
        response.setStreet(fuelStation.getAddress().street());
        response.setFuelTanks(
            fuelStation.getFuelTanks()
                .stream()
                .map(t -> new FuelTankResponse(
                    t.getId(),
                    t.getFuelGrade().toString(),
                    t.getCurrentVolume(),
                    pendingByTankId.getOrDefault(t.getId(), BigDecimal.ZERO),
                    t.getMaxCapacity(),
                    t.getLastRefillDate()))
                .toList());
        response.setFuelPrices(
            fuelStation.getFuelPrices()
                .stream()
                .map(p -> new FuelPriceResponse(
                    p.fuelGrade().toString(),
                    p.pricePerLiter(),
                    p.currency()
                ))
                .toList());
        response.setBuildingNumber(fuelStation.getAddress().buildingNumber());
        response.setCity(fuelStation.getAddress().city());
        response.setPostalCode(fuelStation.getAddress().postalCode());
        response.setCountry(fuelStation.getAddress().country());
        response.setAssignedManagersIds(fuelStation.getAssignedManagersIds());
        response.setStatus(fuelStation.getStatus().toString());
        return response;
    }

    @JsonProperty(value = "address")
    String getAddress() {
        return String.format("%s %s, %s %s, %s", street, buildingNumber, postalCode, city, country);
    }

    public record FuelTankResponse(
        Long id,
        String fuelGrade,
        BigDecimal currentVolume,
        BigDecimal pendingVolume,
        BigDecimal maxCapacity,
        Optional<OffsetDateTime> lastRefillDate) {
    }

    public record FuelPriceResponse(String fuelGrade, BigDecimal pricePerLiter, CurrencyCode currency) {
    }

}
